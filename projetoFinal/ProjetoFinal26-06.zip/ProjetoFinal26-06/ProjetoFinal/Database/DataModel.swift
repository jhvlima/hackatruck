//
//  ViewModel.swift
//  Consumindo apis
//
//  Created by Turma02-27 on 14/06/24.
//

import Foundation

class ViewModel : ObservableObject {
    @Published var users : [user] = []
    
    func fetchTarefas(){
        guard let url = URL(string: "https://fakerapi.it/api/v1/credit_cards?_quantity=500") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            guard let data = data, error == nil else{
                return
            }
            
            do {
                let jsonDecodificado = try JSONDecoder().decode(User.self, from: data)
                
                //colocar o valor em caroes
                DispatchQueue.main.async {
                    self?.users = jsonDecodificado.data
                }
            }catch{
                print(error)
            }
        }
        
        task.resume()
    }
}
