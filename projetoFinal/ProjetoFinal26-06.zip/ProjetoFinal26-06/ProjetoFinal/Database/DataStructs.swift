//
//  model.swift
//  dailyTasks
//
//  Created by Turma02-23 on 25/06/24.
//

import Foundation

enum ESTADO {
    case concluido
    case naoConcluido
    case marcado
    case naoMarcado
}

struct tarefa: Decodable {
    var titulo : String
    var descricao : String
    var imagem : String
    var inicio : Date
    var fim : Date
    var totalDias : Int
    var concluidoDias : Int
    var periodicidade : [Bool]
    var semanaAtual : [Bool]
    var concluido : Bool
}

struct post {
    var imagemPost : String
    var imagemTask : String
    var descricao : String
    var curtida : Int
    var comentarios : [String]
}

struct user : Decodable {
    var tarefasAndamento : [tarefa]
    var tarefasConcluidas : [tarefa]
    var foto : String
    var nome : String
    var descricao : String
    var badges : [String]
    var streak : Int
    var amigos : [String]
}

struct User: Decodable {
    var data: [user]
}



let usuariomocado = user(tarefasAndamento: [
    tarefa(titulo: "Leitura",
           descricao: "Quero ler a primeira trilogia de duna até o final do ano, então vou ler pelo menos uma hora por dia.",
           imagem: "https://blog-static.infra.grancursosonline.com.br/wp-content/uploads/2015/03/03162524/literatura.jpg",
           inicio: Date.now,
           fim: Date.now,
           totalDias: 300,
           concluidoDias: 70,
           periodicidade: [true, true, true, true, true, true, true],
           semanaAtual: [true, true, true, false, false, false, false, false],
           concluido: false),
    tarefa(titulo: "Leitura",
           descricao: "Quero ler a primeira trilogia de duna até o final do ano, então vou ler pelo menos uma hora por dia.",
           imagem: "https://rollingstone.uol.com.br/media/_versions/sylvester-stallone-rocky-balboa-foto-divulgacao_widelg.jpg",
           inicio: Date.now,
           fim: Date.now,
           totalDias: 300,
           concluidoDias: 70,
           periodicidade: [true, true, true, true, true, true, true],
           semanaAtual: [true, true, true, false, false, false, false, false],
           concluido: false),
    tarefa(titulo: "Leitura",
           descricao: "Quero ler a primeira trilogia de duna até o final do ano, então vou ler pelo menos uma hora por dia.",
           imagem: "https://blog-static.infra.grancursosonline.com.br/wp-content/uploads/2015/03/03162524/literatura.jpg",
           inicio: Date.now,
           fim: Date.now,
           totalDias: 300,
           concluidoDias: 70,
           periodicidade: [true, true, true, true, true, true, true],
           semanaAtual: [true, true, true, false, false, false, false, false],
           concluido: false)
], tarefasConcluidas: [
    tarefa(titulo: "Leitura",
           descricao: "Quero ler a primeira trilogia de duna até o final do ano, então vou ler pelo menos uma hora por dia.",
           imagem: "https://blog-static.infra.grancursosonline.com.br/wp-content/uploads/2015/03/03162524/literatura.jpg",
           inicio: Date.now,
           fim: Date.now,
           totalDias: 300,
           concluidoDias: 70,
           periodicidade: [true, true, true, true, true, true, true],
           semanaAtual: [true, true, true, false, false, false, false, false],
           concluido: false),
    tarefa(titulo: "Leitura",
           descricao: "Quero ler a primeira trilogia de duna até o final do ano, então vou ler pelo menos uma hora por dia.",
           imagem: "https://rollingstone.uol.com.br/media/_versions/sylvester-stallone-rocky-balboa-foto-divulgacao_widelg.jpg",
           inicio: Date.now,
           fim: Date.now,
           totalDias: 300,
           concluidoDias: 70,
           periodicidade: [true, true, true, true, true, true, true],
           semanaAtual: [true, true, true, false, false, false, false, false],
           concluido: false),
    tarefa(titulo: "Leitura",
           descricao: "Quero ler a primeira trilogia de duna até o final do ano, então vou ler pelo menos uma hora por dia.",
           imagem: "https://blog-static.infra.grancursosonline.com.br/wp-content/uploads/2015/03/03162524/literatura.jpg",
           inicio: Date.now,
           fim: Date.now,
           totalDias: 300,
           concluidoDias: 70,
           periodicidade: [true, true, true, true, true, true, true],
           semanaAtual: [true, true, true, false, false, false, false, false],
           concluido: false)
], foto: "https://www.hollywoodreporter.com/wp-content/uploads/2024/05/GettyImages-2150913647-copy.jpg?w=1296&h=730&crop=1", nome: "Ryan goslo", descricao: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.", badges: [""], streak: 63, amigos: ["Hugo david", "Vitor S. Passamani", "Gabriel", "Pedro", "Joao"])
