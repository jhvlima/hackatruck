//  Routine.swift
//  ProjetoFinal
//
//  Created by Turma02-12 on 25/06/24.
//

import SwiftUI

struct Routine: View {
    @Environment(\.dismiss) var dismiss
    @State private var progress = 0.5
    var body: some View {

            ZStack
            {
                LinearGradient(colors: [.pBlue, .lightBlue], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            ScrollView
            {
                /*
                    VStack {
                    }
                    .navigationTitle(Text("Hello").foregroundColor(.orange))
                    .navigationBarBackButtonHidden(true)
                    .toolbar {
                        ToolbarItem(placement: .principal) {
                            VStack
                            {
                                HStack {
                                    Button(action: {
                                        dismiss()
                                    }) {
                                        Label("Back", systemImage: "arrow.left").foregroundColor(.white).font(.system(size: 35)).bold().offset(x: -20)
                                        
                                    }
                                    Spacer().frame(width: 50)
                                    Text("Rotina")
                                        .foregroundColor(.white).bold().font(.system(size: 40))
                                    Spacer()
                                }
                                Spacer().frame(width: 200)
                            }
                        }
                    }
                    .toolbarBackground(.visible, for: .navigationBar)
                    .toolbarBackground(.lightBlue, for: .navigationBar)
                    .navigationBarTitleDisplayMode(.inline)
                    */
                    VStack
                    {
                        ZStack
                        {
                            
                            RoundedRectangle(cornerRadius: 10)
                                .foregroundStyle(.white)
                                .frame(width: 350,height: 440 )
                                .opacity(0.2)
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                            VStack {
                                Text("Academia")                            .foregroundColor(.white).bold().font(.system(size: 40))
                                
                                Rectangle()
                                    .frame(width: 350,height: 120)
                                    .foregroundStyle(.white)
                                
                                
                                Text("90/180 dias")
                                    .foregroundColor(.white).bold().font(.system(size: 25))
                                CustomProgressView(progress: progress)
                                    .frame(height: 10)
                                    .padding(.horizontal, 35)
                                
                                Spacer().frame(height: 25)
                                HStack
                                {
                                    ZStack
                                    {
                                        RoundedRectangle(cornerRadius: 10)
                                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                        Text("D").foregroundStyle(.white)
                                        
                                    }
                                    ZStack
                                    {
                                        RoundedRectangle(cornerRadius: 10)
                                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                        Text("S").foregroundStyle(.white)
                                        
                                    }
                                    ZStack
                                    {
                                        RoundedRectangle(cornerRadius: 10)
                                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                        Text("T").foregroundStyle(.white)
                                        
                                    }
                                    ZStack
                                    {
                                        RoundedRectangle(cornerRadius: 10)
                                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                        Text("Q").foregroundStyle(.white)
                                        
                                    }
                                    ZStack
                                    {
                                        RoundedRectangle(cornerRadius: 10)
                                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                        Text("Q").foregroundStyle(.white)
                                        
                                    }
                                    ZStack
                                    {
                                        RoundedRectangle(cornerRadius: 10)
                                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                        Text("S").foregroundStyle(.white)
                                        
                                    }
                                    ZStack
                                    {
                                        RoundedRectangle(cornerRadius: 10)
                                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                        Text("S").foregroundStyle(.white)
                                        
                                    }
                                    
                                }
                                Spacer().frame(height: 30)
                                HStack
                                {
                                    ZStack
                                    {
                                        RoundedRectangle(cornerRadius: 10)
                                            .foregroundStyle(.green)
                                            .frame(width: 140, height: 45 ).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                        Text("CONCLUIR")
                                            .foregroundColor(.white).bold().font(.system(size: 25))
                                    }
                                    ZStack
                                    {
                                        RoundedRectangle(cornerRadius: 10)
                                            .foregroundStyle(.yellow)
                                            .frame(width: 140, height: 45 ).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                        Text("EDITAR")
                                            .foregroundColor(.white).bold().font(.system(size: 25))
                                    }
                                }
                            }
                        }
                    }
                    
                }
            }
            
        
    }
}


#Preview {
    Routine()
}
