//
//  Search.swift
//  ProjetoFinal
//
//  Created by Turma02-12 on 25/06/24.
//

import SwiftUI

struct Search: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Search()
}
