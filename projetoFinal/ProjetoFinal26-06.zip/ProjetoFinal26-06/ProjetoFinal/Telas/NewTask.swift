//
//  NewTask.swift
//  ProjetoFinal
//
//  Created by Turma02-12 on 25/06/24.
//

import SwiftUI

struct NewTask: View {
    @State private var dataInicio = Date.now
    @State private var dataFim = Date.now

    @State var nome : String = ""
    @State var descricao : String = ""
    @State var tag : String = ""

    //@State var novaTarefa : tarefa(titulo: " ", descricao: " ", imagem: " ", inicio: <#T##Date#>, fim: <#T##Date#>, totalDias: 0, concluidoDias: 0, periodicidade: <#T##[Bool]#>, semanaAtual: [, concluido: false)
    

    var body: some View {
        
        ZStack
        {
            // FUNDO
            LinearGradient(colors: [.pBlue, .lightBlue], startPoint: .top, endPoint: .bottom)
            
            VStack{
                // titulo
                VStack{
                        Text("Titulo")
                        .foregroundStyle(.white)
                        .bold()
                        ZStack{
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.white)
                            .frame(width: 350,height: 60 )
                            .opacity(0.1)
                            TextField("De um nome para a sua tarefa", text: $nome).padding()
                    }
                        
                }
                
                // descricao
                VStack{
                    Text("Descrição")
                        .foregroundStyle(.white)
                        .bold()
                    ZStack{
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.white)
                            .frame(width: 350,height: 80 )
                            .opacity(0.1)
                        TextField("De uma descrição para sua tarefa", text: $descricao).padding()
                    }
                }
                
                // imagem
                ZStack{
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundStyle(.white)
                        .frame(width: 350,height: 100 )
                        .opacity(0.1)
                    VStack{
                        Image(systemName: "photo.badge.plus.fill")
                            .resizable()
                            .frame(width: 50, height: 39)
                            .foregroundStyle(.white)
                        Text("Adicionar imagem")
                            .foregroundStyle(.white)
                            .bold()
                    }
                }
                
                // datas
                VStack{
                    DatePicker(selection: $dataInicio, in: ...Date.now, displayedComponents: .date) {
                        Text("Data de início:")
                            .foregroundStyle(.white)
                            .bold()
                    }.colorScheme(.dark)
                    
                    DatePicker(selection: $dataFim, in: ...Date.now, displayedComponents: .date) {
                        Text("Data de fim:")
                            .foregroundStyle(.white)
                            .bold()
                    }.colorScheme(.dark)
                    //Text("Date is \(dataInicio.formatted(date: .numeric, time: .omitted))")
                }.padding()
                // periodicidade dos dias da semana
                HStack
                {
                    ZStack
                    {
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                        Text("D").foregroundStyle(.white)
                        
                    }
                    ZStack
                    {
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                        Text("S").foregroundStyle(.white)
                        
                    }
                    ZStack
                    {
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                        Text("T").foregroundStyle(.white)
                        
                    }
                    ZStack
                    {
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                        Text("Q").foregroundStyle(.white)
                        
                    }
                    ZStack
                    {
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                        Text("Q").foregroundStyle(.white)
                        
                    }
                    ZStack
                    {
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                        Text("S").foregroundStyle(.white)
                        
                    }
                    ZStack
                    {
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                        Text("S").foregroundStyle(.white)
                        
                    }

                }
                
                // tag
                HStack{
                        Text("Tag")
                        .foregroundStyle(.white)
                        .bold()
                        ZStack{
                            RoundedRectangle(cornerRadius: 10)
                                .foregroundStyle(.white)
                                .frame(width: 300,height: 60 )
                                .opacity(0.1)
                                TextField("De uma Tag para a sua tarefa", text: $nome).padding()
                        }
                }.padding()
                
                // salvar
                ZStack{
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundStyle(.green)
                        .frame(width: 100, height: 50 )
                    Text("Salvar")
                        .foregroundStyle(.white)
                        .bold()
                }
            }
        }.ignoresSafeArea()
    }
}

#Preview {
    NewTask()
}
