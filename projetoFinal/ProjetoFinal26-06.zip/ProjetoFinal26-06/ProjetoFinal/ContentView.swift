//
//  ContentView.swift
//  ProjetoFinal
//
//  Created by Turma02-12 on 25/06/24.
//

import SwiftUI

struct CustomProgressView: View {
    let progress: CGFloat
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Rectangle()
                    .frame(width: geometry.size.width, height: 20)
                    .opacity(0.3)
                    .foregroundColor(.gray)
                    .cornerRadius(10)
                
                Rectangle()
                    .frame(
                        width: min(progress * geometry.size.width,
                                   geometry.size.width),
                        height: 20
                    )
                    .foregroundColor(.pBlue)
                    .cornerRadius(10)
            }
        }
    }
}

struct ContentView: View {
    @State private var progress = 0.5
    var body: some View {
        NavigationStack
        {
            ZStack
            {
                // FUNDO
                LinearGradient(colors: [.pBlue, .lightBlue], startPoint: .top, endPoint: .bottom)
                ScrollView // POSTS
                {
                    VStack{
                        Spacer()
                        ZStack
                        {
                            RoundedRectangle(cornerRadius: 10)
                                .foregroundStyle(.white)
                                .frame(width: 350,height: 450 )
                                .opacity(0.1)
                            VStack
                            {
                                Spacer()
                                HStack
                                {
                                    Spacer()
                                        .frame(width: 20)
                                    Circle()
                                        .frame(width: 40,height: 40)
                                        .foregroundStyle(.white)
                                    VStack{
                                        HStack
                                        {
                                            Text("Username")
                                                .foregroundStyle(.white)
                                                .bold()
                                            Spacer()
                                        }
                                        HStack
                                        {
                                            Text("Mais um desafio concluído!")
                                                .foregroundStyle(.white)
                                            Spacer()
                                        }
                                    }
                                    Image(systemName: "ellipsis")
                                        .resizable()
                                        .frame(width: 24,height: 6)
                                        .foregroundStyle(.brinco)
                                        .bold()
                                    Spacer().frame(width:30)
                                }
                                Spacer()
                                Rectangle()
                                    .frame(width: 350,height: 200)
                                    .foregroundStyle(.white)
                                Spacer()
                                VStack
                                {
                                    Text("Leitura")
                                        .foregroundStyle(.brinco)
                                        .bold()
                                        .font(.title)
                                    Text("3/10 dias")
                                        .foregroundStyle(.brinco)
                                        .bold()
                                        .font(.headline)
                                    CustomProgressView(progress: progress)
                                                                    .frame(height: 10)
                                                                    .padding(.horizontal, 35)
                                                                
                                                                
                                    /*
                                    ZStack
                                    {
                                        RoundedRectangle(cornerRadius: 100)
                                            .foregroundStyle(.white)
                                            .frame(width: 320, height: 20)
                                        RoundedRectangle(cornerRadius: 100)
                                            .foregroundStyle(.pBlue)
                                            .frame(width: 100, height: 20)
                                            .padding(.trailing,220)
                                    }
                                    */
                                    Spacer()
                                }
                                HStack
                                {
                                    Spacer()
                                    HStack
                                    {
                                        Spacer().frame(width: 20)
                                        VStack(alignment: .leading)
                                        {
                                            Spacer().frame(height:-5)
                                            Text("**vitorpassamani**: lindo!!!")
                                                .foregroundStyle(.brinco)
                                                
                                                .multilineTextAlignment(/*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/)
                                            Text("**taylorswift**: eu te amo!!!")
                                                .foregroundStyle(.brinco)
                                                
                                            Text("Adicione um comentário...")
                                                .foregroundStyle(.brinco)
                                                .font(.headline)
                                        }
                                        Spacer()
                                    }
                                    
                                    Spacer()
                                    Image(systemName: "heart.fill")
                                        .resizable()
                                        .frame(width: 48,height: 43)
                                        .foregroundStyle(.pRed)
                                        .bold()
                                    Spacer()
                                        .frame(width:40)
                                }
                                Spacer().frame(height:15)
                            }
                            
                        }
                    }
                    .padding(.top,30)
                }
                ZStack // BARRA INFERIOR
                {
                    VStack
                    {
                        ZStack
                        {
                            Rectangle()
                                .size(width: 400, height: 70)
                                .foregroundStyle(.pBlue)
                            HStack
                            {
                                Spacer()
                                NavigationLink(destination: Search())
                                {
                                    Image(systemName: "magnifyingglass")
                                        .resizable()
                                        .frame(width: 40,height: 40)
                                        .foregroundStyle(.brinco)
                                        .bold()
                                }
                                Spacer()
                                NavigationLink(destination: Routine())
                                {
                                    Image(systemName: "calendar")
                                        .resizable()
                                        .frame(width: 40,height: 40)
                                        .foregroundStyle(.brinco)
                                        .bold()
                                }
                                Spacer()
                                NavigationLink(destination: Profile(usuario: usuariomocado))
                                {
                                    Image(systemName: "person.fill")
                                        .resizable()
                                        .frame(width: 40,height: 40)
                                        .foregroundStyle(.brinco)
                                        .bold()
                                }
                                Spacer()
                                    .frame(width: 135)
                            }
                            
                        }
                    }.padding(.top,597)
                    HStack{
                        Spacer()
                        VStack{
                            Spacer()
                            NavigationLink(destination: NewTask())
                            {
                                ZStack
                                {
                                    Circle().frame(width: 100, height: 100).padding()
                                    Image(systemName: "plus")
                                        .resizable()
                                        .frame(width: 40,height: 40)
                                        .foregroundStyle(.brinco)
                                        .bold()
                                }
                                
                            }
                        }
                    }
                }
            }.ignoresSafeArea()
        }
    }
}

#Preview {
    ContentView()
}
