//
//  Profile.swift
//  ProjetoFinal
//
//  Created by Turma02-12 on 25/06/24.
//

import SwiftUI

//global

public var nome:String? = nil
public var descricao: String? = nil

struct Profile: View {
    @State var usuario: user
    var body: some View {
        NavigationStack{
            ZStack{
                LinearGradient(colors: [.pBlue, .lightBlue], startPoint: .top, endPoint: .bottom)
                ScrollView{
                    VStack(spacing: 0){
                        ZStack{//capa de perfil
                            VStack{
                                Color(.white)
                                    .frame(height:170)
                                Spacer()
                            }
                            
                            //foto
                            AsyncImage(url: URL(string: usuariomocado.foto)) { image in
                                image.resizable()
                                    .scaledToFit()
                                    .clipShape(Circle())
                                    .frame(width: 300)
                            } placeholder: {
                                ProgressView()
                            }.padding(.top, 50)
                            
                            //botao
                            NavigationLink(destination: EditProfile(usuario: usuariomocado)){
                                ZStack{
                                    RoundedRectangle(cornerRadius: 10)
                                        .frame(width: 105, height: 30)
                                        .foregroundStyle(.lightBlue)
                                    Text("Editar Perfil")
                                        .bold()
                                        .foregroundStyle(.white)
                                }
                            }.padding(.leading, 250)
                                .padding(.top, 200)
                        }
                        HStack{//nome + streak
                            if nome != nil{
                                Text("@\(nome!)")
                                    .font(.largeTitle)
                                    .bold()
                                    .foregroundStyle(.white)
                                HStack(spacing: 2){
                                    Image(systemName: "flame.fill")
                                        .foregroundStyle(.red)
                                    Text(String(usuariomocado.streak))
                                        .foregroundStyle(.red)
                                        .bold()
                                }.padding(.top, 5)
                            } else {
                                Text("@\(usuariomocado.nome)")
                                    .font(.largeTitle)
                                    .bold()
                                    .foregroundStyle(.white)
                                HStack(spacing: 2){
                                    Image(systemName: "flame.fill")
                                        .foregroundStyle(.red)
                                    Text(String(usuariomocado.streak))
                                        .foregroundStyle(.red)
                                        .bold()
                                }.padding(.top, 5)
                            }
                        }
                        Text("\"\(usuario.descricao)\"")
                            .bold()
                            .foregroundStyle(.white)
                            .padding(.bottom, 20)
                            .padding(.top, 10)
                            .padding(.leading, 10)
                        HStack{//badges
                            VStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 30, height: 30)
                                    .foregroundColor(.white)
                                Text("x dias")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                            VStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 30, height: 30)
                                    .foregroundColor(.white)
                                Text("x dias")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                            VStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 30, height: 30)
                                    .foregroundColor(.white)
                                Text("x dias")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        }
                        //Friend list:
                        NavigationLink(destination: FriendsList()){
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 200, height: 30)
                                    .foregroundStyle(.lightBlue)
                                Text("Lista de Amigos(42)")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        }.padding(.top, 5)
                    }
                    VStack{//post
                        Spacer()
                        ZStack
                        {
                            RoundedRectangle(cornerRadius: 10)
                                .foregroundStyle(.white)
                                .frame(width: 350,height: 450 )
                                .opacity(0.1)
                            VStack
                            {
                                Spacer()
                                HStack
                                {
                                    Spacer()
                                        .frame(width: 20)
                                    Circle()
                                        .frame(width: 40,height: 40)
                                        .foregroundStyle(.white)
                                    VStack{
                                        HStack
                                        {
                                            Text("Username")
                                                .foregroundStyle(.white)
                                                .bold()
                                            Spacer()
                                        }
                                        HStack
                                        {
                                            Text("Mais um desafio concluído!")
                                                .foregroundStyle(.white)
                                            Spacer()
                                        }
                                    }
                                    Image(systemName: "ellipsis")
                                        .resizable()
                                        .frame(width: 24,height: 6)
                                        .foregroundStyle(.brinco)
                                        .bold()
                                    Spacer().frame(width:30)
                                }
                                Spacer()
                                Rectangle()
                                    .frame(width: 350,height: 200)
                                    .foregroundStyle(.white)
                                Spacer()
                                VStack
                                {
                                    Text("Leitura")
                                        .foregroundStyle(.brinco)
                                        .bold()
                                        .font(.title)
                                    Text("3/10 dias")
                                        .foregroundStyle(.brinco)
                                        .bold()
                                        .font(.headline)
                                    ZStack
                                    {
                                        RoundedRectangle(cornerRadius: 100)
                                            .foregroundStyle(.white)
                                            .frame(width: 320, height: 20)
                                        RoundedRectangle(cornerRadius: 100)
                                            .foregroundStyle(.pBlue)
                                            .frame(width: 100, height: 20)
                                            .padding(.trailing,220)
                                    }
                                    
                                    Spacer()
                                }
                                HStack
                                {
                                    Spacer()
                                    HStack
                                    {
                                        Spacer().frame(width: 20)
                                        VStack(alignment: .leading)
                                        {
                                            Spacer().frame(height:-5)
                                            Text("*vitorpassamani*: lindo!!!")
                                                .foregroundStyle(.brinco)
                                            
                                                .multilineTextAlignment(.leading)
                                            Text("*taylorswift*: eu te amo!!!")
                                                .foregroundStyle(.brinco)
                                            
                                            Text("Adicione um comentário...")
                                                .foregroundStyle(.brinco)
                                                .font(.headline)
                                        }
                                        Spacer()
                                    }
                                    
                                    Spacer()
                                    Image(systemName: "heart.fill")
                                        .resizable()
                                        .frame(width: 48,height: 43)
                                        .foregroundStyle(.pRed)
                                        .bold()
                                    Spacer()
                                        .frame(width:40)
                                }
                                Spacer().frame(height:15)
                            }
                            
                        }
                    }.padding(.top, 5)
                    VStack{//post
                        Spacer()
                        ZStack
                        {
                            RoundedRectangle(cornerRadius: 10)
                                .foregroundStyle(.white)
                                .frame(width: 350,height: 450 )
                                .opacity(0.1)
                            VStack
                            {
                                Spacer()
                                HStack
                                {
                                    Spacer()
                                        .frame(width: 20)
                                    Circle()
                                        .frame(width: 40,height: 40)
                                        .foregroundStyle(.white)
                                    VStack{
                                        HStack
                                        {
                                            Text("Username")
                                                .foregroundStyle(.white)
                                                .bold()
                                            Spacer()
                                        }
                                        HStack
                                        {
                                            Text("Mais um desafio concluído!")
                                                .foregroundStyle(.white)
                                            Spacer()
                                        }
                                    }
                                    Image(systemName: "ellipsis")
                                        .resizable()
                                        .frame(width: 24,height: 6)
                                        .foregroundStyle(.brinco)
                                        .bold()
                                    Spacer().frame(width:30)
                                }
                                Spacer()
                                Rectangle()
                                    .frame(width: 350,height: 200)
                                    .foregroundStyle(.white)
                                Spacer()
                                VStack
                                {
                                    Text("Leitura")
                                        .foregroundStyle(.brinco)
                                        .bold()
                                        .font(.title)
                                    Text("3/10 dias")
                                        .foregroundStyle(.brinco)
                                        .bold()
                                        .font(.headline)
                                    ZStack
                                    {
                                        RoundedRectangle(cornerRadius: 100)
                                            .foregroundStyle(.white)
                                            .frame(width: 320, height: 20)
                                        RoundedRectangle(cornerRadius: 100)
                                            .foregroundStyle(.pBlue)
                                            .frame(width: 100, height: 20)
                                            .padding(.trailing,220)
                                    }
                                    
                                    Spacer()
                                }
                                HStack
                                {
                                    Spacer()
                                    HStack
                                    {
                                        Spacer().frame(width: 20)
                                        VStack(alignment: .leading)
                                        {
                                            Spacer().frame(height:-5)
                                            Text("*vitorpassamani*: lindo!!!")
                                                .foregroundStyle(.brinco)
                                            
                                                .multilineTextAlignment(.leading)
                                            Text("*taylorswift*: eu te amo!!!")
                                                .foregroundStyle(.brinco)
                                            
                                            Text("Adicione um comentário...")
                                                .foregroundStyle(.brinco)
                                                .font(.headline)
                                        }
                                        Spacer()
                                    }
                                    
                                    Spacer()
                                    Image(systemName: "heart.fill")
                                        .resizable()
                                        .frame(width: 48,height: 43)
                                        .foregroundStyle(.pRed)
                                        .bold()
                                    Spacer()
                                        .frame(width:40)
                                }
                                Spacer().frame(height:15)
                            }
                            
                        }
                    }.padding(.top, 2)
                }
            }.ignoresSafeArea()
        }
    }
}

#Preview {
    Profile(usuario: usuariomocado)
}
