//
//  Profile.swift
//  ProjetoFinal
//
//  Created by Turma02-12 on 25/06/24.
//

import SwiftUI

struct EditProfile: View {
    @State var usuario: user
    var body: some View {
        NavigationStack{
            ZStack{
                LinearGradient(colors: [.pBlue, .lightBlue], startPoint: .top, endPoint: .bottom)
                ScrollView{
                    ZStack{
                        VStack{
                            ZStack{
                                Color(.white)
                                    .frame(height:170)
                                    .opacity(0.2)
                                Image(systemName: "photo.badge.plus.fill")
                                    .resizable()
                                    .frame(width: 100, height: 80)
                                    .foregroundColor(.brinco)
                            }
                            Spacer()
                        }
                        ZStack{
                            AsyncImage(url: URL(string: usuariomocado.foto)) { image in
                                image.resizable()
                                    .scaledToFit()
                                    .clipShape(Circle())
                                    .frame(width: 300)
                                    .opacity(0.7)
                            } placeholder: {
                                ProgressView()
                            }
                            Image(systemName: "plus.app.fill")
                                .resizable()
                                .frame(width: 80, height: 80)
                                .foregroundColor(.brinco)
                        }.padding(.top, 200)
                    }
                    HStack{
                        Text("Nome:")
                            .font(.title)
                            .bold()
                            .foregroundStyle(.white)
                        Spacer()
                    }.padding()
                    
                    TextField(
                        "nome",
                        text: $usuario.nome
                    )
                    .foregroundStyle(.white)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .padding(.leading)
                    
                    HStack{
                        Text("Descrição:")
                            .font(.title)
                            .bold()
                            .foregroundStyle(.white)
                        Spacer()
                    }.padding()
                    
                    TextField(
                        "descricao",
                        text: $usuario.descricao
                    )
                    .foregroundStyle(.white)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .padding(.leading)
                    
                    Button{
                        //nome = usuario.nome
                        //descricao = usuario.descricao
                    } label: {
                        ZStack{
                            RoundedRectangle(cornerRadius: 10)
                                .frame(width: 160, height: 30)
                                .foregroundStyle(.lightBlue)
                            Text("Salvar")
                                .bold()
                                .foregroundStyle(.white)
                        }
                    }.padding()
                }
            }.ignoresSafeArea()
        }
    }
}



#Preview {
    EditProfile(usuario: usuariomocado)
}
