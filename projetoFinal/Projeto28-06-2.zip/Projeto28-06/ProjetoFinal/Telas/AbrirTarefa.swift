//
//  abrirTarefa.swift
//  ProjetoFinal
//
//  Created by Turma02-9 on 28/06/24.
//

import SwiftUI

struct AbrirTarefa: View {
    @State private var progress = 0.5
    @State var tarefaAberta: tarefa

    var body: some View {
        ZStack
        {
            
            // FUNDO
            LinearGradient(colors: [.pBlue, .lightBlue], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            ScrollView
            {
                ZStack
                {
                    
                    VStack {
                        Text("\(tarefaAberta.titulo)")                            .foregroundColor(.white).bold().font(.system(size: 40))
                        
                        AsyncImage(url: URL(string: tarefaAberta.imagem)) { image in
                            image.resizable()
                                .resizable()
                                .frame(width: 380,height:235)
                        } placeholder: {
                            ProgressView()
                        }
                        
                        
                        Text("\(tarefaAberta.descricao)")
                            .foregroundColor(.white).font(.system(size: 25)).multilineTextAlignment(.center)
                        Spacer().frame(height: 20)
                        HStack
                        {
                     
                            Spacer()
                            VStack
                            {
                                Text("Data de Inicio")
                                    .foregroundColor(.white).bold().font(.system(size: 25))
                                Text("\(tarefaAberta.inicio.formatted(date: .numeric, time: .omitted))")
                                    .foregroundColor(.white).font(.system(size: 20))
                            }
                            Spacer()
                            VStack
                            {
                                Text("Data de Fim")
                                    .foregroundColor(.white).bold().font(.system(size: 25))
                                Text("\(tarefaAberta.fim.formatted(date: .numeric, time: .omitted))")
                                    .foregroundColor(.white).font(.system(size: 20))
                            }
                            Spacer()
                        }.padding(.top,-5)
                        Text("\(tarefaAberta.concluidoDias)/\(tarefaAberta.totalDias) dias")
                            .foregroundColor(.white).bold().font(.system(size: 25))
                            .padding(.top,10)
                        
                        CustomProgressView(progress: Double(tarefaAberta.concluidoDias)/Double(tarefaAberta.totalDias))
                                                            .frame(height: 10)
                                                            .padding(.horizontal, 35)
                                                            .padding(.bottom,10)
                        
                        Spacer().frame(height: 25)
                        

                        HStack
                        {
                            AsyncImage(url: URL(string: usuariomocado.foto)) { image in
                                image.resizable()
                                    .resizable()
                                    .frame(width: 100,height:100)
                            } placeholder: {
                                ProgressView()
                            }
                            AsyncImage(url: URL(string: usuariomocado.foto)) { image in
                                image.resizable()
                                    .resizable()
                                    .frame(width: 100,height:100)
                            } placeholder: {
                                ProgressView()
                            }
                            AsyncImage(url: URL(string: usuariomocado.foto)) { image in
                                image.resizable()
                                    .resizable()
                                    .frame(width: 100,height:100)
                            } placeholder: {
                                ProgressView()
                            }
                        }
                        HStack
                        {
                            AsyncImage(url: URL(string: usuariomocado.foto)) { image in
                                image.resizable()
                                    .resizable()
                                    .frame(width: 100,height:100)
                            } placeholder: {
                                ProgressView()
                            }
                            AsyncImage(url: URL(string: usuariomocado.foto)) { image in
                                image.resizable()
                                    .resizable()
                                    .frame(width: 100,height:100)
                            } placeholder: {
                                ProgressView()
                            }
                            AsyncImage(url: URL(string: usuariomocado.foto)) { image in
                                image.resizable()
                                    .resizable()
                                    .frame(width: 100,height:100)
                            } placeholder: {
                                ProgressView()
                            }
                        }
                    
                    }
                }
            }
        }
    }
}

#Preview {
    AbrirTarefa(tarefaAberta: tarefa(titulo: "Leitura", descricao: "\"Temos que ler mais\"", imagem: "https://cienciaparaeducacao.org/wp-content/uploads/2022/02/fluencia-de-leitura.jpeg", inicio: Date(), fim: Date(), totalDias: 180, concluidoDias: 90, periodicidade: [false,false,false,false,false,false,false], concluido: false, diasFeitos: [false,false,false,false,false,false,false]))
}
