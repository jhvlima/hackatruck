//
//  FriendsList.swift
//  ProjetoFinal
//
//  Created by Turma02-27 on 27/06/24.
//

import SwiftUI

struct FriendsList: View {
    @State var amigo1 = false
    @State var amigo2 = false
    @State var amigo3 = false
    @State var amigo4 = false
    @State var amigo5 = false
    @State var amigo6 = false
    @State var amigo7 = false
    @State var amigo8 = false
    @State var amigo9 = false
    var body: some View {
        ZStack{
            LinearGradient(colors: [.pBlue, .lightBlue], startPoint: .top, endPoint: .bottom)
            ScrollView{
                HStack{//AMIGO 1
                    AsyncImage(url: URL(string: "https://media.licdn.com/dms/image/D4D03AQHZtrKaSgz34Q/profile-displayphoto-shrink_200_200/0/1712279623773?e=2147483647&v=beta&t=1OZEBxmA4NO4DN3FZnfnMC15IxJ2m8J0NeRWouEbWcQ")) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }.clipShape(Circle())
                        .frame(width: 50, height: 50)
                    Text("@Hugo")
                        .padding(.leading, 2)
                        .foregroundStyle(.white)
                        .bold()
                        .multilineTextAlignment(.leading)
                    Spacer()
                    Button{
                        amigo1.toggle()
                    } label: {
                        if amigo1{
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.lightBlue)
                                Text("Adicionar")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        } else {
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.pRed)
                                Text("Desfazer Amizade")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        }
                    }.padding(.trailing, 20)
                        .padding(.top, 10)
                }.padding()
                    .padding(.top, 50)
                HStack{//AMIGO 2
                    AsyncImage(url: URL(string: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Gabriel_Medina_2.jpg/640px-Gabriel_Medina_2.jpg")) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }.clipShape(Circle())
                        .frame(width: 50, height: 50)
                    Text("@Gabriel")
                        .padding(.leading, 2)
                        .foregroundStyle(.white)
                        .bold()
                        .multilineTextAlignment(.leading)
                    Spacer()
                    Button{
                        amigo2.toggle()
                    } label: {
                        if amigo2{
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.lightBlue)
                                Text("Adicionar")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        } else {
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.pRed)
                                Text("Desfazer Amizade")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        }
                    }.padding(.trailing, 20)
                        .padding(.top, 10)
                }.padding()
                HStack{//AMIGO 3
                    AsyncImage(url: URL(string: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQa9Qdg8LWh-e40zhFEzIxzb2cYo9ec1yzGzw&s")) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }.clipShape(Circle())
                        .frame(width: 50, height: 50)
                    Text("@Joao")
                        .padding(.leading, 2)
                        .foregroundStyle(.white)
                        .bold()
                        .multilineTextAlignment(.leading)
                    Spacer()
                    Button{
                        amigo3.toggle()
                    } label: {
                        if amigo3{
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.lightBlue)
                                Text("Adicionar")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        } else {
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.pRed)
                                Text("Desfazer Amizade")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        }
                    }.padding(.trailing, 20)
                        .padding(.top, 10)
                }.padding()
                HStack{//AMIGO 4
                    AsyncImage(url: URL(string: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZALnHdMD-Sm_znUeXseC-02T35xP1dUvong&s")) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }.clipShape(Circle())
                        .frame(width: 50, height: 50)
                    Text("@pedro")
                        .padding(.leading, 2)
                        .foregroundStyle(.white)
                        .bold()
                        .multilineTextAlignment(.leading)
                    Spacer()
                    Button{
                        amigo4.toggle()
                    } label: {
                        if amigo4{
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.lightBlue)
                                Text("Adicionar")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        } else {
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.pRed)
                                Text("Desfazer Amizade")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        }
                    }.padding(.trailing, 20)
                        .padding(.top, 10)
                }.padding()
                HStack{//AMIGO 5
                    AsyncImage(url: URL(string: "https://diariodopara.dol.com.br/wp-content/uploads/2024/06/harry-divulgacao.jpg")) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }.clipShape(Circle())
                        .frame(width: 50, height: 50)
                    Text("@harry")
                        .padding(.leading, 2)
                        .foregroundStyle(.white)
                        .bold()
                        .multilineTextAlignment(.leading)
                    Spacer()
                    Button{
                        amigo5.toggle()
                    } label: {
                        if amigo5{
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.lightBlue)
                                Text("Adicionar")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        } else {
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.pRed)
                                Text("Desfazer Amizade")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        }
                    }.padding(.trailing, 20)
                        .padding(.top, 10)
                }.padding()
                HStack{//AMIGO 6
                    AsyncImage(url: URL(string: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ9jLkfc9CEbtMPFWONPmMP79pPwM1YZexuJg&s")) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }.clipShape(Circle())
                        .frame(width: 50, height: 50)
                    Text("@renato")
                        .padding(.leading, 2)
                        .foregroundStyle(.white)
                        .bold()
                        .multilineTextAlignment(.leading)
                    Spacer()
                    Button{
                        amigo6.toggle()
                    } label: {
                        if amigo6{
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.lightBlue)
                                Text("Adicionar")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        } else {
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.pRed)
                                Text("Desfazer Amizade")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        }
                    }.padding(.trailing, 20)
                        .padding(.top, 10)
                }.padding()
                HStack{//AMIGO 7
                    AsyncImage(url: URL(string: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSXmpbg0-268hGxjW7n99UetQulpGRiJxmEVQ&s")) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }.clipShape(Circle())
                        .frame(width: 50, height: 50)
                    Text("@marcos")
                        .padding(.leading, 2)
                        .foregroundStyle(.white)
                        .bold()
                        .multilineTextAlignment(.leading)
                    Spacer()
                    Button{
                        amigo7.toggle()
                    } label: {
                        if amigo7{
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.lightBlue)
                                Text("Adicionar")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        } else {
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.pRed)
                                Text("Desfazer Amizade")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        }
                    }.padding(.trailing, 20)
                        .padding(.top, 10)
                }.padding()
                HStack{//AMIGO 9
                    AsyncImage(url: URL(string: "https://img.lovepik.com/photo/50249/5638.jpg_wh860.jpg")) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }.clipShape(Circle())
                        .frame(width: 50, height: 50)
                    Text("@renan")
                        .padding(.leading, 2)
                        .foregroundStyle(.white)
                        .bold()
                        .multilineTextAlignment(.leading)
                    Spacer()
                    Button{
                        amigo9.toggle()
                    } label: {
                        if amigo9{
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.lightBlue)
                                Text("Adicionar")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        } else {
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width: 160, height: 30)
                                    .foregroundStyle(.pRed)
                                Text("Desfazer Amizade")
                                    .bold()
                                    .foregroundStyle(.white)
                            }
                        }
                    }.padding(.trailing, 20)
                        .padding(.top, 10)
                }.padding()
            }
        }.ignoresSafeArea()
    }
}

#Preview {
    FriendsList()
}
