//
//  Search.swift
//  ProjetoFinal
//
//  Created by Turma02-12 on 25/06/24.
//

import SwiftUI

struct Search: View {
    var body: some View {
        ZStack{
            LinearGradient(colors: [.pBlue, .lightBlue], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            VStack
            {
                ZStack
                {
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundStyle(.white)
                        .frame(width: 350,height: 45 )
                        .opacity(0.2)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                    HStack
                    {
                        Spacer().frame(width: 70)
                        Text("Buscar usuário")
                            .foregroundColor(.white).font(.system(size: 25)).multilineTextAlignment(.center)
                        Spacer().frame(width: 40)
                        Image("Lupa")
                            .resizable()
                            .frame(width: 35, height: 35)
                    }.padding()
                }
                HStack
                {
                    Text("Recentes")
                        .foregroundColor(.white).font(.system(size: 25))
                        .offset(x: 30)
                    Spacer()
                }
                HStack
                {
                    VStack
                    {
                        AsyncImage(url: URL(string: usuariomocado.foto)) { image in
                            image.resizable()
                                .scaledToFit()
                                .clipShape(Circle())
                                .frame(width: 80, height: 80).offset(x: 10)
                        } placeholder: {
                            ProgressView()
                        }
                        Text("@ryangosling")
                            .foregroundColor(.white).font(.caption)
                            .offset(x: 10, y: -20)
                    }
                    VStack
                    {
                        AsyncImage(url: URL(string: usuariomocado.foto)) { image in
                            image.resizable()
                                .scaledToFit()
                                .clipShape(Circle())
                                .frame(width: 80, height: 80).offset(x: 10)
                        } placeholder: {
                            ProgressView()
                        }
                        Text("@ryangosling")
                            .foregroundColor(.white).font(.caption)
                            .offset(x: 10, y: -20)
                    }
                    VStack
                    {
                        AsyncImage(url: URL(string: usuariomocado.foto)) { image in
                            image.resizable()
                                .scaledToFit()
                                .clipShape(Circle())
                                .frame(width: 80, height: 80).offset(x: 10)
                        } placeholder: {
                            ProgressView()
                        }
                        Text("@ryangosling")
                            .foregroundColor(.white).font(.caption)
                            .offset(x: 10, y: -20)
                    }
                    VStack
                    {
                        AsyncImage(url: URL(string: usuariomocado.foto)) { image in
                            image.resizable()
                                .scaledToFit()
                                .clipShape(Circle())
                                .frame(width: 80, height: 80).offset(x: 10)
                        } placeholder: {
                            ProgressView()
                        }
                        Text("@ryangosling")
                            .foregroundColor(.white).font(.caption)
                            .offset(x: 10, y: -20)
                    }
                }.offset(y: -10)
                Spacer()
            }
        }
    }
}

#Preview {
    Search()
}
