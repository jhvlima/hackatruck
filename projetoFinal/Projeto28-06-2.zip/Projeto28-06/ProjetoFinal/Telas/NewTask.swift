//
//  NewTask.swift
//  ProjetoFinal
//
//  Created by Turma02-12 on 25/06/24.
//

import SwiftUI
import PhotosUI

struct NewTask: View {
//  Variaveis para teste
//    @State private var dataInicio = Date.now
//    @State private var dataFim = Date.now
//    @State var nome : String = ""
//    @State var descricao : String = ""
//    @State var novaTarefa.periodicidade = [false,false,false,false,false,false,false]
    @State private var avatarItem: PhotosPickerItem? = nil
    @State private var avatarImage: UIImage? = nil
    @State private var diferencaData = DateComponents()

    @State var novaTarefa = tarefa(titulo: "", descricao: "", imagem: "https://dnd1g0gk41u1l.cloudfront.net/image/filename/5002881/x_lg_VNPdes39LrmbqK7rysrC-DKwIQkIpv4r.png", inicio: Date(), fim: Date(), totalDias: 0, concluidoDias: 1, periodicidade: [false,false,false,false,false,false,false], concluido: false, diasFeitos: [false,true,false,true,false,true,false])
    
    @StateObject var vm = ViewModel()
    
    var body: some View {
        
        ZStack
        {
            // FUNDO
            LinearGradient(colors: [.pBlue, .lightBlue], startPoint: .top, endPoint: .bottom)
            
            VStack{
                // titulo
                VStack{
                    Text("Titulo")
                        .foregroundStyle(.white)
                        .bold()
                    ZStack{
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.white)
                            .frame(width: 350,height: 60 )
                            .opacity(0.1)
                        TextField("De um nome para a sua tarefa", text: $novaTarefa.titulo).padding()
                    }
                    
                }
                
                // descricao
                VStack{
                    Text("Descrição")
                        .foregroundStyle(.white)
                        .bold()
                    ZStack{
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.white)
                            .frame(width: 350,height: 80 )
                            .opacity(0.1)
                        TextField("De uma descrição para sua tarefa", text: $novaTarefa.descricao).padding()
                    }
                }
                
                // imagem
                ZStack{

                    RoundedRectangle(cornerRadius: 10)
                        .foregroundStyle(.white)
                        .frame(width: 350,height: 150 )
                        .opacity(0.1)
                    VStack{
                        PhotosPicker(selection: $avatarItem, matching: .images, photoLibrary: .shared()) {
                            ZStack{
                                Text("Adicionar Imagem")

                                Image(uiImage: avatarImage ?? UIImage())
                                 .resizable()
                                 .scaledToFill()
                                 .frame(width: 350, height: 150)
                                 .clipShape(RoundedRectangle(cornerRadius: 10))
                            }
                        }.onChange(of: avatarItem) {
                            Task { @MainActor in
                                if let data = try? await avatarItem?.loadTransferable(type: Data.self) {
                                    avatarImage = UIImage(data:data)
                                    return
                                }
                            }
                        }
                    }
                }
                
                // datas
                VStack{
                    DatePicker(selection: $novaTarefa.inicio, in: ...Date.now, displayedComponents: .date) {
                        Text("Data de início:")
                            .foregroundStyle(.white)
                            .bold()
                    }.colorScheme(.dark)
                    DatePicker(selection: $novaTarefa.fim, in: ...Date.now.addingTimeInterval(99999999), displayedComponents: .date) {
                        Text("Data de fim:")
                            .foregroundStyle(.white)
                            .bold()
                    }.colorScheme(.dark)
                }.padding()
                
                // periodicidade dos dias da semana
                HStack
                {
                    Button{
                        novaTarefa.periodicidade[0] = !novaTarefa.periodicidade[0]
                    }label: {
                        ZStack
                        {
                            if novaTarefa.periodicidade[0] {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.green).frame(width: 35, height: 35).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.green, lineWidth: 3))
                                Text("D").foregroundStyle(.white)
                            }
                            else {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                                Text("D").foregroundStyle(.white)
                            }
                        }
                    }
                    Button{
                        novaTarefa.periodicidade[1] = !novaTarefa.periodicidade[1]
                    }label: {
                        ZStack
                        {
                            if novaTarefa.periodicidade[1] {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.green).frame(width: 35, height: 35).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.green, lineWidth: 3))
                                Text("S").foregroundStyle(.white)
                            }
                            else {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                                Text("S").foregroundStyle(.white)
                            }
                        }
                    }
                    Button{
                        novaTarefa.periodicidade[2] = !novaTarefa.periodicidade[2]
                    }label: {
                        ZStack
                        {
                            if novaTarefa.periodicidade[2] {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.green).frame(width: 35, height: 35).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.green, lineWidth: 3))
                                Text("T").foregroundStyle(.white)
                            }
                            else {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                                Text("T").foregroundStyle(.white)
                            }
                        }
                    }
                    Button{
                        novaTarefa.periodicidade[3] = !novaTarefa.periodicidade[3]
                    }label: {
                        ZStack
                        {
                            if novaTarefa.periodicidade[3] {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.green).frame(width: 35, height: 35).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.green, lineWidth: 3))
                                Text("Q").foregroundStyle(.white)
                            }
                            else {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                                Text("Q").foregroundStyle(.white)
                            }
                        }
                    }
                    Button{
                        novaTarefa.periodicidade[4] = !novaTarefa.periodicidade[4]
                    }label: {
                        ZStack
                        {
                            if novaTarefa.periodicidade[4] {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.green).frame(width: 35, height: 35).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.green, lineWidth: 3))
                                Text("Q").foregroundStyle(.white)
                            }
                            else {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                                Text("Q").foregroundStyle(.white)
                            }
                        }
                    }
                    Button{
                        novaTarefa.periodicidade[5] = !novaTarefa.periodicidade[5]
                    }label: {
                        ZStack
                        {
                            if novaTarefa.periodicidade[5] {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.green).frame(width: 35, height: 35).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.green, lineWidth: 3))
                                Text("S").foregroundStyle(.white)
                            }
                            else {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                                Text("S").foregroundStyle(.white)
                            }
                        }
                    }
                    Button{
                        novaTarefa.periodicidade[6] = !novaTarefa.periodicidade[6]
                    }label: {
                        ZStack
                        {
                            if novaTarefa.periodicidade[6] {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.green).frame(width: 35, height: 35).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.green, lineWidth: 3))
                                Text("S").foregroundStyle(.white)
                            }
                            else {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 3))
                                Text("S").foregroundStyle(.white)
                            }
                        }
                    }

                }
                
                // salvar
                Button{
                    // salva todas as variaveis
                    diferencaData = Calendar.current.dateComponents([.day], from: novaTarefa.inicio, to: novaTarefa.fim)
                    novaTarefa.totalDias = diferencaData.day! + 1

                    // manda pra database
                    vm.postTarefas(novaTarefa)

                }label: {
                    ZStack{
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.green)
                            .frame(width: 100, height: 50 )
                        Text("Salvar")
                            .foregroundStyle(.white)
                            .bold()
                    }
                }
                //Text("\(novaTarefa.totalDias)")
                //Text("\(novaTarefa.inicio.formatted(date: .long, time: .omitted))")
            }
        }.ignoresSafeArea()
    }
}

#Preview {
    NewTask()
}
