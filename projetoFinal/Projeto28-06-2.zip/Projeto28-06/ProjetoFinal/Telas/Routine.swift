//
//  Routine.swift
//  ProjetoFinal
//
//  Created by Turma02-12 on 25/06/24.
//

import SwiftUI


struct Routine: View {
    @StateObject var vm = ViewModel()
    var body: some View {
        NavigationStack{
            ZStack
            {
                LinearGradient(colors: [.pBlue, .lightBlue], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
                ZStack
                {
                    ScrollView
                    {
                        /*
                         VStack {
                         }
                         .navigationTitle(Text("Hello").foregroundColor(.orange))
                         .navigationBarBackButtonHidden(true)
                         .toolbar {
                         ToolbarItem(placement: .principal) {
                         VStack
                         {
                         HStack {
                         Button(action: {
                         dismiss()
                         }) {
                         Label("Back", systemImage: "arrow.left").foregroundColor(.white).font(.system(size: 35)).bold().offset(x: -20)
                         
                         }
                         Spacer().frame(width: 50)
                         Text("Rotina")
                         .foregroundColor(.white).bold().font(.system(size: 40))
                         Spacer()
                         }
                         Spacer().frame(width: 200)
                         
                         }
                         }
                         .toolbarBackground(.visible, for: .navigationBar)
                         .toolbarBackground(.lightBlue, for: .navigationBar)
                         .navigationBarTitleDisplayMode(.inline)
                         */
                        
                        ForEach(vm.tarefas, id: \.self) {tarefa in
                            NavigationLink(destination: AbrirTarefa(tarefaAberta: tarefa)){
                                ZStack
                                {
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .foregroundStyle(.white)
                                        .frame(width: 350,height: 440 )
                                        .opacity(0.2)
                                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                    VStack {
                                        Text(tarefa.titulo) .foregroundColor(.white).bold().font(.system(size: 40))
                                        
                                        AsyncImage(url: URL(string: tarefa.imagem)) { image in
                                            image.resizable()
                                        } placeholder: {
                                            ProgressView()
                                        }.scaledToFill()
                                            .frame(width:350, height: 120)
                                            .clipped()
                                            .foregroundStyle(.white)
                                        
                                        
                                        Text("\(tarefa.concluidoDias)/\(tarefa.totalDias) dias")
                                            .foregroundColor(.white).bold().font(.system(size: 25))
                                        CustomProgressView(progress: Double(tarefa.concluidoDias)/Double(tarefa.totalDias))
                                            .frame(height: 10)
                                            .padding(.horizontal, 35)
                                        
                                        Spacer().frame(height: 25)
                                        HStack
                                        {
                                            ForEach((0...6), id: \.self){ n in
                                                ZStack
                                                {
                                                    if tarefa.diasFeitos[n]{
                                                        RoundedRectangle(cornerRadius: 10)
                                                            .foregroundStyle(.green).frame(width: 35, height: 35).opacity(1).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.green, lineWidth: 1))
                                                    } else if !tarefa.diasFeitos[n] && tarefa.periodicidade[n] {
                                                        RoundedRectangle(cornerRadius: 10)
                                                            .foregroundStyle(.white).frame(width: 35, height: 35).opacity(0).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                                    } else if !tarefa.periodicidade[n] {
                                                        RoundedRectangle(cornerRadius: 10)
                                                            .strokeBorder(Color.white, style: StrokeStyle(lineWidth: 1, dash: [5]))
                                                            .frame(width: 35, height: 35)
                                                    }
                                                    
                                                    switch n {
                                                    case 0:
                                                        Text("D").foregroundStyle(.white)
                                                    case 1:
                                                        Text("S").foregroundStyle(.white)
                                                    case 2:
                                                        Text("T").foregroundStyle(.white)
                                                    case 3:
                                                        Text("Q").foregroundStyle(.white)
                                                    case 4:
                                                        Text("Q").foregroundStyle(.white)
                                                    case 5:
                                                        Text("S").foregroundStyle(.white)
                                                    case 6:
                                                        Text("S").foregroundStyle(.white)
                                                    default:
                                                        Text("").foregroundStyle(.white)
                                                    }
                                                    
                                                }
                                            }
                                        }
                                        Spacer().frame(height: 30)
                                        HStack
                                        {
                                            ZStack
                                            {
                                                RoundedRectangle(cornerRadius: 10)
                                                    .foregroundStyle(.green)
                                                    .frame(width: 140, height: 45 ).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                                Text("CONCLUIR")
                                                    .foregroundColor(.white).bold().font(.system(size: 25))
                                            }
                                            ZStack
                                            {
                                                RoundedRectangle(cornerRadius: 10)
                                                    .foregroundStyle(.yellow)
                                                    .frame(width: 140, height: 45 ).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white, lineWidth: 1))
                                                Text("EDITAR")
                                                    .foregroundColor(.white).bold().font(.system(size: 25))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    VStack{
                        Spacer()
                        NavigationLink(destination: NewTask()){
                            ZStack
                            {
                                Circle().frame(width: 100, height: 100).padding().foregroundColor(.lightBlue)
                                Image(systemName: "plus")
                                    .resizable()
                                    .frame(width: 40,height: 40)
                                    .foregroundStyle(.brinco)
                                    .bold()
                            }
                        }
                    }
                }.onAppear{
                    vm.fetchTarefas()
                }
            }
        }
    }
}


#Preview {
    Routine()
}
