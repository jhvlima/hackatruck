//
//  EditarTarefa.swift
//  ProjetoFinal
//
//  Created by Turma02-22 on 28/06/24.
//

import SwiftUI

struct EditarTarefa: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    EditarTarefa()
}
