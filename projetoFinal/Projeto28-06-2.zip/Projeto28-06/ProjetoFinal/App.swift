//
//  ProjetoFinalApp.swift
//  ProjetoFinal
//
//  Created by Turma02-12 on 25/06/24.
//

import SwiftUI

@main
struct ProjetoFinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
