//
//  model.swift
//  dailyTasks
//
//  Created by Turma02-23 on 25/06/24.
//

import Foundation

struct tarefa: Codable, Hashable {
    var titulo : String
    var descricao : String
    var imagem : String
    var inicio : Date
    var fim : Date
    var totalDias : Int
    var concluidoDias : Int
    var periodicidade : [Bool]
    var concluido : Bool
    var diasFeitos : [Bool]
}

struct post: Codable, Hashable {
    var imagemUser : String
    var nomeUser : String
    var descricao : String
    var imagemPost : String
    var titulo : String
    var totalDias : Int
    var concluidoDias : Int
    var comentarios : [comentario]
}

//struct Tarefas: Codable {
//    var data: [tarefa]
//}

//struct Posts: Codable {
//    var data: [post]
//}

struct user : Decodable {
    var foto : String
    var nome : String
    var descricao : String
    var badges : [String]
    var streak : Int
    var amigos : [String]
}

struct comentario : Codable, Hashable {
    var usuario: String
    var texto: String
}

let usuariomocado = user(
    foto:"https://www.hollywoodreporter.com/wp-content/uploads/2024/05/GettyImages-2150913647-copy.jpg?w=1296&h=730&crop=1",
    nome: "Ryan goslo",
    descricao: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.",
    badges: [""],
    streak: 63,
    amigos: ["Hugo david", "Vitor S. Passamani", "Gabriel", "Pedro", "Joao"])
