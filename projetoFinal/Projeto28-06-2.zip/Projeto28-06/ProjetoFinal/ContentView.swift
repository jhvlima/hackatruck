//
//  ContentView.swift
//  ProjetoFinal
//
//  Created by Turma02-12 on 25/06/24.
//

import SwiftUI

struct CustomProgressView: View {
    let progress: CGFloat
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Rectangle()
                    .frame(width: geometry.size.width, height: 20)
                    .opacity(0.3)
                    .foregroundColor(.gray)
                    .cornerRadius(10)
                
                Rectangle()
                    .frame(
                        width: min(progress * geometry.size.width,
                                   geometry.size.width),
                        height: 20
                    )
                    .foregroundColor(.pBlue)
                    .cornerRadius(10)
            }
        }
    }
}

struct ContentView: View {
    @StateObject var vm = ViewModel()
    var body: some View {
        NavigationStack
        {
            ZStack
            {
                // FUNDO
                LinearGradient(colors: [.pBlue, .lightBlue], startPoint: .top, endPoint: .bottom)
                ScrollView // POSTS
                {
                    VStack{
                        Spacer()
                        ForEach(vm.posts, id: \.self){ post in
                            ZStack
                            {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundStyle(.white)
                                    .frame(width: 350,height: 450 )
                                    .opacity(0.1)
                                VStack
                                {
                                    Spacer()
                                    HStack
                                    {
                                        
                                        Spacer()
                                            .frame(width: 20)
                                        AsyncImage(url: URL(string: post.imagemUser)) { image in
                                            image.resizable()
                                                .scaledToFit()
                                                .clipShape(Circle())
                                                .frame(width: 45, height: 45)
                                        } placeholder: {
                                            ProgressView()
                                        }
                                          
                                        VStack{
                                            HStack
                                            {
                                                Text(post.nomeUser)
                                                    .foregroundStyle(.white)
                                                    .bold()
                                                Spacer()
                                            }
                                            HStack
                                            {
                                                Text(post.descricao)
                                                    .foregroundStyle(.white)
                                                Spacer()
                                            }
                                        }
                                        Image(systemName: "ellipsis")
                                            .resizable()
                                            .frame(width: 24,height: 6)
                                            .foregroundStyle(.brinco)
                                            .bold()
                                        Spacer().frame(width:30)
                                    }
                                    Spacer()
                                    AsyncImage(url: URL(string: post.imagemPost)) { image in
                                        image.resizable()
                                            .frame(width: 350, height:200)
                                    } placeholder: {
                                        ProgressView()
                                    }
                                    Spacer()
                                    VStack
                                    {
                                        
                                        Text(post.titulo)
                                            .foregroundStyle(.brinco)
                                            .bold()
                                            .font(.title)
                                        Text(String(post.concluidoDias)+"/"+String(post.totalDias)+" Dias")
                                            .foregroundStyle(.brinco)
                                            .bold()
                                            .font(.headline)
                                        CustomProgressView(progress: Double(post.concluidoDias)/Double(post.totalDias))
                                                                        .frame(height: 10)
                                                                        .padding(.horizontal, 35)
                                        Spacer()
                                    }
                                    HStack
                                    {
                                        Spacer()
                                        HStack
                                        {
                                            Spacer().frame(width: 10)
                                            VStack(alignment: .leading)
                                            {
                                                Spacer()
                                                ForEach(post.comentarios, id:\.self){ comentario in
                                                    HStack
                                                    {
                                                        Spacer().frame(width:2)
                                                        Text(comentario.usuario+":")
                                                            .foregroundStyle(.brinco)
                                                            .multilineTextAlignment(/*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/)
                                                            .bold()
                                                        Text(comentario.texto)
                                                            .foregroundStyle(.brinco)
                                                            .multilineTextAlignment(/*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/)
                                                    }
                                                    
                                                }
                                                
                                                    
                                                Spacer()
                                                Text("Adicione um comentário...")
                                                    .foregroundStyle(.brinco)
                                                    .font(.headline)
                                                Spacer().frame(height:1)
                                            }
                                            Spacer()
                                        }
                                        
                                        Spacer()
                                        Image(systemName: "heart.fill")
                                            .resizable()
                                            .frame(width: 48,height: 43)
                                            .foregroundStyle(.pRed)
                                            .bold()
                                        Spacer()
                                            .frame(width:40)
                                    }
                                    Spacer().frame(height:5)
                                }
                                
                            }
                            Spacer()
                        }
                    }
                    .padding(.top,30)
                }
                ZStack // BARRA INFERIOR
                {
                    VStack
                    {
                        ZStack
                        {
                            Rectangle()
                                .size(width: 400, height: 70)
                                .foregroundStyle(.pBlue)
                            HStack
                            {
                                Spacer()
                                NavigationLink(destination: Search())
                                {
                                    Image(systemName: "magnifyingglass")
                                        .resizable()
                                        .frame(width: 40,height: 40)
                                        .foregroundStyle(.brinco)
                                        .bold()
                                }
                                Spacer()
                                NavigationLink(destination: Routine())
                                {
                                    Image(systemName: "calendar")
                                        .resizable()
                                        .frame(width: 40,height: 40)
                                        .foregroundStyle(.brinco)
                                        .bold()
                                }
                                Spacer()
                                NavigationLink(destination: Profile(usuario: usuariomocado))
                                {
                                    Image(systemName: "person.fill")
                                        .resizable()
                                        .frame(width: 40,height: 40)
                                        .foregroundStyle(.brinco)
                                        .bold()
                                }
                                Spacer()
                                    .frame(width: 135)
                            }
                            
                        }
                    }.padding(.top,597)
                    HStack{
                        Spacer()
                        VStack{
                            Spacer()
                            NavigationLink(destination: NewTask())
                            {
                                ZStack
                                {
                                    Circle().frame(width: 100, height: 100).padding()
                                    Image(systemName: "plus")
                                        .resizable()
                                        .frame(width: 40,height: 40)
                                        .foregroundStyle(.brinco)
                                        .bold()
                                }
                                
                            }
                        }
                    }
                }
            }.ignoresSafeArea().onAppear{
                vm.fetchPosts()
            }
        }
    }
}

#Preview {
    ContentView()
}
